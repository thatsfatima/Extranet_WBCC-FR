<?php

ini_set('default_socket_timeout', 2000);

echo ini_get('default_socket_timeout');